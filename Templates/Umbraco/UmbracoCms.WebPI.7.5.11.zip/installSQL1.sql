/**********************************************************************/
/* Install.SQL                                                        */
/* Creates a login and makes the user a member of db roles            */
/*                                                                    */
/*           Modifications for SQL AZURE  - ON MASTER                 */
/**********************************************************************/

if(not exists(select name from sys.database_principals where name = PlaceHolderForUser))
begin
	CREATE LOGIN PlaceHolderForUser WITH PASSWORD = 'PlaceHolderForPassword'
end