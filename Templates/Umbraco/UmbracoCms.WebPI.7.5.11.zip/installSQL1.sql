/**********************************************************************/
/* Install.SQL                                                        */
/* Creates a login and makes the user a member of db roles            */
/*                                                                    */
/*           Modifications for SQL AZURE  - ON MASTER                 */
/**********************************************************************/

if(not exists(select name from sys.syslogins where name = 'PlaceHolderForUser'))
begin
	CREATE LOGIN PlaceHolderForUser WITH PASSWORD = 'PlaceHolderForPassword'
end