/**********************************************************************/
/* Install.SQL                                                        */
/* Creates a login and makes the user a member of db roles            */
/*                                                                    */
/*           Modifications for SQL AZURE  - ON MASTER                 */
/**********************************************************************/


CREATE LOGIN PlaceHolderForUser WITH PASSWORD = 'PlaceHolderForPassword'