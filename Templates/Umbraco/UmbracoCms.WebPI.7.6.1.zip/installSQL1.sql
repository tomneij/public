/**********************************************************************/
/* Install.SQL                                                        */
/* Creates a login and makes the user a member of db roles            */
/*                                                                    */
/*           Modifications for SQL AZURE  - ON MASTER                 */
/**********************************************************************/

BEGIN TRY  
	CREATE LOGIN PlaceHolderForUser WITH PASSWORD = 'PlaceHolderForPassword'
END TRY  
BEGIN CATCH  
	print 'warning, could not create login PlaceHolderForUser'
END CATCH 